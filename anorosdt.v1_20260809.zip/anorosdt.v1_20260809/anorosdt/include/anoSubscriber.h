#ifndef _ANOSUBSCRIBER_H_
#define _ANOSUBSCRIBER_H_

#include <AnoPTv7.h>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <tf/transform_broadcaster.h>
#include <tf/tf.h>
#include <tf2_msgs/TFMessage.h>  
#include <tf2/LinearMath/Transform.h>  
#include <tf2_ros/transform_listener.h>  
//#include <anoros_dt.h>

#include <anorosdt/RemoteControl.h>
#include <anorosdt/AnoRosDT_User.h>
#include <anorosdt/AnoRosDT_KZFC.h>
#include <anorosdt/AnoRosGPS.h>


#include <tf2_ros/buffer.h>
#include <geometry_msgs/TransformStamped.h>

class AnoSub
{
	public:
		struct sSetTopic
		{
			std::string subTopicNameCmdVel;
        	std::string subTopicNamePos_T265;
        	std::string subTopicNamePos_Radar;
        	std::string subTopicNameUserData;
		};
	public:
		sSetTopic m_setTopic;

		ros::Subscriber m_subUserData, m_subT265, m_subRadar, m_subRadarMap;//初始化订阅者话题

		void readSettings_Sub(void); 
		void anoSubCreate_Init(void);

		void SubUserData(const anorosdt::AnoRosDT_KZFC data);
        void SubT265Data(const nav_msgs::Odometry::ConstPtr& msg);
        void SubRadarData(const tf2_msgs::TFMessage::ConstPtr& msg);
        void SubRadarMapReady(const nav_msgs::OccupancyGrid::ConstPtr& msg);

        // 由飞控0xFC指令控制雷达TF定时器启停
        void SetRadarTimerEnabled(bool enable);
        bool IsRadarTimerEnabled(void) const;

	public:
  		AnoSub(ros::NodeHandle& nh);

	private:
  		void SubRadarTimer(const ros::TimerEvent&);

		tf2_ros::Buffer tf_buffer_;
		tf2_ros::TransformListener tf_listener_;

		ros::Timer radar_timer_;
        ros::Timer radar_start_delay_timer_;
        bool radar_timer_enabled_;
        bool radar_start_pending_;

        void RadarStartDelayTimer(const ros::TimerEvent&);
};
struct sMsgCmdVel
{
    int16_t acc[3];
    int16_t yaw;
    uint8_t sendFalg;
};

extern sMsgCmdVel cmdVel;


#endif

