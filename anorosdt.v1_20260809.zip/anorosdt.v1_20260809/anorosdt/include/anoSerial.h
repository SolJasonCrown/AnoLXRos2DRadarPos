#ifndef _ANOSERIAL_H_
#define _ANOSERIAL_H_

#include <AnoPTv7.h>
#include <cstdlib>
#include "anoros_dt.h"

struct sMsgImu 
{
    float acc[3];
    float gyr[3];
    float ori[4];
    bool flagMemsReady;
    bool flagOriReady;
};
struct sMsgMag 
{
    float mag[3];
};
struct sMsgSpd 
{
    float vel[3];
};
struct sMsgOF 
{
    float x;
    float y;
    float z;
};

struct sMsgGPS 
{
    uint8_t FIX_STA;
    uint8_t S_NUM;
    int32_t LNG;
    int32_t LAT;
    int32_t ALT_GPS;
    int16_t N_SPE;
    int16_t E_SPE;
    int16_t D_SPE;
    uint8_t PDOP_001;
    uint8_t SACC_001;
    uint8_t VACC_001;
};

struct sMsgAlt
{
    float Alt;
    float Fus;
};

struct sMsgRC
{
    uint16_t ch1_rol;
    uint16_t ch2_pit;
    uint16_t ch3_thr;
    uint16_t ch4_yaw;
    uint16_t ch5_aux1;
    uint16_t ch6_aux2;
    uint16_t ch7_aux3;
    uint16_t ch8_aux4;
    uint16_t ch9_aux5;
    uint16_t ch10_aux6;
};

//用户数据结构体
struct User_Data
{
    int8_t s81;
    int8_t s82;
    int8_t s83;
    int16_t s161;
    int16_t s162;
    int16_t s163;
};


extern sMsgImu anoMsgImu;
extern sMsgMag anoMsgMag;
extern sMsgSpd anoMsgImuSpd;
extern sMsgOF  anoMsgOF;
extern sMsgGPS anoMsgGPS;
extern sMsgAlt anoMsgAlt;
extern sMsgRC  anoMsgRC;
extern User_Data UserData;//用户数据


extern serial::Serial Stm32_Serial; //声明串口对象

void Serial_Init(void);

void AnoDTRaspRunTask1Ms(void);

bool AnoPTv7RecvOneByte(uint8_t data);
bool anoRosDTRaspDataFrameAnl(uint8_t *data);

// 雷达定位定时器控制命令（由飞控通过0xFC下发）
enum RadarTimerControlCmd
{
    RADAR_TIMER_CMD_NONE  = 0,
    RADAR_TIMER_CMD_START = 1,
    RADAR_TIMER_CMD_STOP  = 2
};

// 取出并清除一次待处理的雷达定时器控制命令
uint8_t AnoTakeRadarTimerControlCommand(void);

//通用发送函数
void AnoPTv7SendBuf(const uint8_t ID,const uint8_t* buf, const uint8_t len);

#endif




