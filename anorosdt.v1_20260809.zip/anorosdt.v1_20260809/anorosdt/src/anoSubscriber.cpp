#include "anoSubscriber.h"
#include <anoSerial.h>

sMsgCmdVel cmdVel;


AnoSub::AnoSub(ros::NodeHandle& nh)
  : tf_listener_(tf_buffer_),
    radar_timer_enabled_(false),
    radar_start_pending_(false)
{
  // 创建雷达TF定时器，但上电默认不启动。
  // 默认不启动；SLAM /map就绪并延时2秒后会自动start()。
  // 原0xFC控制仍可作为调试备用，但飞控无需发送即可正常自动工作。
  radar_timer_ = nh.createTimer(
      ros::Duration(0.02),     // 50Hz
      &AnoSub::SubRadarTimer,
      this,
      false,                   // oneshot = false，周期定时器
      false                    // autostart = false，上电不启动
  );

  // 2秒延时启动定时器：收到SLAM发布的第一帧/map后启动一次。
  // oneshot=true，autostart=false。
  radar_start_delay_timer_ = nh.createTimer(
      ros::Duration(2.0),
      &AnoSub::RadarStartDelayTimer,
      this,
      true,
      false
  );

  ROS_INFO("Radar TF timer created, waiting for SLAM /map ready");
}

void AnoSub::SetRadarTimerEnabled(bool enable)
{
  if (enable)
  {
    if (!radar_timer_enabled_)
    {
      radar_timer_.start();
      radar_timer_enabled_ = true;
      ROS_INFO("Radar TF timer STARTED");
    }
  }
  else
  {
    if (radar_timer_enabled_)
    {
      radar_timer_.stop();
      radar_timer_enabled_ = false;
      ROS_INFO("Radar TF timer STOPPED");
    }
  }
}

bool AnoSub::IsRadarTimerEnabled(void) const
{
  return radar_timer_enabled_;
}

/*
初始化发布节点的名称
*/
void AnoSub::readSettings_Sub(void) 
{
	ros::NodeHandle SubSet_n("~"); //创建节点句柄
    try
    {
    	//发布话题名称
    	SubSet_n.param<std::string>	("subTopicNamePos_T265",	this->m_setTopic.subTopicNamePos_T265,	"/camera/odom/sample");//T265数据
    	//SubSet_n.param<std::string>	("subTopicNamePos_Radar",	this->m_setTopic.subTopicNamePos_Radar,	"/tf");//激光雷达定位数据
    	SubSet_n.param<std::string>	("subTopicNameUserData",	this->m_setTopic.subTopicNameUserData,	"/sendKZFC_data");//用户数据

        ROS_INFO( "settings read ok");
    }
    catch (serial::IOException& e)
	{
	     ROS_INFO("settings read no");
	}   
}


void AnoSub::anoSubCreate_Init(void)
{
  ros::NodeHandle sub_n; //创建似有节点句柄

	m_subT265 	= sub_n.subscribe(this->m_setTopic.subTopicNamePos_T265,	 100,	&AnoSub::SubT265Data,this);//获取t265数据
	//m_subRadar  = sub_n.subscribe(this->m_setTopic.subTopicNamePos_Radar,	 100,	&AnoSub::SubRadarData,this);//获取雷达建图定位数据
	m_subUserData = sub_n.subscribe(this->m_setTopic.subTopicNameUserData, 50,	&AnoSub::SubUserData,this);//测试代码，主要测试订阅话题并发送数据到下位机

  // 自动检测SLAM是否已经开始工作。
  // /map由Cartographer occupancy_grid / Hector / Gmapping等建图算法正常工作后发布。
  // 首次收到/map后延时2秒，再确认map->laser_frame TF有效，随后自动开启雷达定位定时器。
  m_subRadarMap = sub_n.subscribe("/map", 1, &AnoSub::SubRadarMapReady, this);
}


/*
功能：通过串口发送数据到下位机，测试代码
*/
void AnoSub::SubUserData(const anorosdt::AnoRosDT_KZFC data)
{
  uint8_t _buf[10];
  uint8_t _cnt = 0;
  int16_t _val = 0;

  _val = data.ACC_X;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = data.ACC_Y;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = data.ACC_Z;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = data.YAW;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  AnoPTv7SendBuf(0x31,_buf,sizeof(_buf));
}

/*
功能：t265数据获取
*/
void AnoSub::SubT265Data(const nav_msgs::Odometry::ConstPtr& msg)
{
  uint8_t _buf[14];
  uint8_t _cnt = 0;
  int16_t _val = 0;

  //位置信息
  _val = msg->pose.pose.position.x*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;
  
  _val = msg->pose.pose.position.y*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = msg->pose.pose.position.z*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  //速度信息
  _val = msg->twist.twist.linear.x*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = msg->twist.twist.linear.y*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = msg->twist.twist.linear.z*100;
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  AnoPTv7SendBuf(0x32,_buf,sizeof(_buf));
}

/*
功能：检测SLAM建图/定位是否已经开始。
说明：只要收到/map，说明建图算法已经开始产生地图输出。
      不立即发送位置，而是启动一个2秒的一次性延时定时器。
*/
void AnoSub::SubRadarMapReady(const nav_msgs::OccupancyGrid::ConstPtr& msg)
{
  (void)msg;

  // 已经在发送，或者已经进入2秒等待阶段，不重复启动。
  if (radar_timer_enabled_ || radar_start_pending_)
    return;

  radar_start_pending_ = true;
  radar_start_delay_timer_.setPeriod(ros::Duration(2.0), true);
  radar_start_delay_timer_.start();

  ROS_INFO("SLAM /map detected, radar position output will start after 2.0 s");
}

/*
功能：/map出现后的2秒延时回调。
      只有map -> laser_frame TF真正建立后，才开启50Hz定位数据获取。
*/
void AnoSub::RadarStartDelayTimer(const ros::TimerEvent&)
{
  radar_start_pending_ = false;

  if (radar_timer_enabled_)
    return;

  // 不能只相信/map存在，还要确认最终需要的组合TF已经可查询。
  if (tf_buffer_.canTransform(
          "map",
          "laser_frame",
          ros::Time(0),
          ros::Duration(0.10)))
  {
    SetRadarTimerEnabled(true);
    ROS_INFO("SLAM ready: map -> laser_frame available, radar position output AUTO STARTED");
  }
  else
  {
    // 不报连续错误，也不强行启动。后续新的/map消息会再次触发2秒检测。
    ROS_WARN("SLAM /map exists but map -> laser_frame is not ready; waiting for next /map");
  }
}

/*
功能：激光雷达建图定位数据获取
*/

void AnoSub::SubRadarData(const tf2_msgs::TFMessage::ConstPtr& msg)
{
  uint8_t _buf[8];
  uint8_t _cnt = 0;
  int16_t _val = 0;

  int16_t _val_1[3] = {0};
  int16_t _val_2[3] = {0};

  for (const auto& transform_stamped : msg->transforms)  
  { 
    if (transform_stamped.header.frame_id == "map" &&
    transform_stamped.child_frame_id == "odom" )
   {
      // 提取平移信息  
      const geometry_msgs::Vector3& translation = transform_stamped.transform.translation;  
      _val_1[0] = translation.x * 100;  
      _val_1[1] = translation.y * 100;  
      _val_1[2] = translation.z * 100;  
    } 
	  if (transform_stamped.header.frame_id == "odom" &&
		  transform_stamped.child_frame_id == "laser_frame" )
	 {
			// 提取平移信息  
			const geometry_msgs::Vector3& translation = transform_stamped.transform.translation;  
      _val_2[0] = translation.x * 100;  
      _val_2[1] = translation.y * 100;  
      _val_2[2] = translation.z * 100;  

      PosData.X = translation.x ;
      PosData.Y = translation.y;
      PosData.Z = translation.z ;
	  } 
  }  
    //位置信息
  _val = _val_1[0] + _val_2[0];
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;
  
  _val = _val_1[1] + _val_2[1];
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;

  _val = _val_1[2] + _val_2[2];
  memcpy(_buf + _cnt, (uint8_t*)(&_val), 2);
  _cnt += 2;
  AnoPTv7SendBuf(0x33,_buf,sizeof(_buf));
}

/*
功能：激光雷达建图定位数据获取（直接用于飞控定位）
坐标系：map → laser_frame
*/

void AnoSub::SubRadarTimer(const ros::TimerEvent&)
{
  uint8_t  _buf[8] = {0};
  uint8_t  _cnt = 0;
  int16_t  _val = 0;

  geometry_msgs::TransformStamped tf_map_to_laser;

  try
  {
    tf_map_to_laser = tf_buffer_.lookupTransform(
        "map",           // 世界坐标
        "laser_frame",   // 雷达坐标（你的 frame_id）
        ros::Time(0),    // 最新一帧
        ros::Duration(0.05)
    );
  }
  catch (tf2::TransformException &ex)
  {
    ROS_WARN_THROTTLE(1.0, "TF lookup failed: %s", ex.what());
    return;
  }

  // ===== 位置（单位：米 → 厘米）=====
  double x = tf_map_to_laser.transform.translation.x;
  double y = tf_map_to_laser.transform.translation.y;
  double z = tf_map_to_laser.transform.translation.z;

  PosData.X = x;
  PosData.Y = y;
  PosData.Z = z;

  int16_t x_cm = static_cast<int16_t>(x * 100);
  int16_t y_cm = static_cast<int16_t>(y * 100);
  int16_t z_cm = static_cast<int16_t>(z * 100);

  memcpy(_buf + _cnt, &x_cm, 2); _cnt += 2;
  memcpy(_buf + _cnt, &y_cm, 2); _cnt += 2;
  memcpy(_buf + _cnt, &z_cm, 2); _cnt += 2;

  // ===== 下发给飞控 =====
  AnoPTv7SendBuf(0x33, _buf, sizeof(_buf));
}



